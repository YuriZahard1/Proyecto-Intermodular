# Memoria técnica del Frontend · Veintiuno (Blackjack)

**Proyecto Interdisciplinar 2** · HTML5 semántico, CSS3 y JavaScript nativo.

## 1. Enlaces

| Recurso | Enlace |
|---|---|
| Prototipo de Figma (Proyecto 1) | _pegar aquí el enlace de Figma_ |
| Web desplegada | _pegar aquí el enlace de GitHub Pages / Netlify / Vercel_ |
| Repositorio (`proyecto-daw-frontend`) | _pegar aquí el enlace de GitHub_ |
| Tablero Kanban | _pegar aquí el enlace de GitHub Projects / Trello_ |

Fidelidad Figma ↔ web: se respetan la paleta, la tipografía (Playfair Display + Inter), la escala de espaciado de 8 px, los radios y las sombras de la guía de estilos, recogidos como variables CSS (ver §3.1) y mostrados en `pages/guia-estilos.html`.

## 2. Estructura del proyecto

```
blackjack/
├── index.html              Dashboard (grid de tarjetas)
├── pages/
│   ├── login.html          Acceso
│   ├── registro.html       Alta de usuario
│   ├── crear.html          Formulario de inserción (registrar partida)
│   ├── detalle.html        Ficha detallada de una partida
│   ├── jugar.html          Mesa de Blackjack
│   └── guia-estilos.html   Sistema de diseño
├── css/
│   ├── variables.css       Variables :root (colores, espaciado, radios, sombras, fuentes)
│   ├── base.css            Reset, tipografía, utilidades
│   ├── components.css      Botones, formularios, badges, cartas, modales
│   ├── layout.css          Maquetación por zonas (Flexbox / Grid) — diseño de escritorio
│   └── responsive.css      Media queries (tablet y móvil)
├── js/
│   ├── mockData.js         "Base de datos" simulada (array de objetos)
│   ├── storage.js          Persistencia local: usuarios, sesión, CRUD de partidas
│   ├── dom.js              Utilidades DOM: createElement (h), cartas, modales
│   ├── validation.js       Reglas y validación en tiempo real
│   ├── layout.js           Común a todas las páginas: acceso, hamburguesa, modales
│   ├── auth.js             login.html y registro.html
│   ├── dashboard.js        index.html (render, buscador, filtros)
│   ├── crear.js            crear.html
│   ├── detalle.js          detalle.html
│   ├── game.js             Reglas del Blackjack (lógica pura, sin DOM)
│   └── jugar.js            Interfaz de la mesa
└── assets/favicon.svg
```

**Decisiones:**

- **Una página HTML por pantalla**, navegables entre sí con enlaces `<a>`, y la cabecera/pie repetidos en cada una para que el HTML sea válido y funcione sin JS para la navegación.
- **Scripts clásicos con un único espacio de nombres (`window.BJ`)** en lugar de módulos ES. Así la web funciona abriendo `index.html` con doble clic (los módulos ES quedan bloqueados en `file://`) y también en cualquier hosting.
- **CSS dividido por responsabilidad** (variables → base → componentes → layout → responsive), cargado en ese orden.
- Cada página declara su comportamiento con atributos en `<body>`: `data-access` (`private` / `guest-only`), `data-root` (ruta a la raíz) y `data-nav` (enlace activo).

## 3. Justificación de maquetación

### 3.1 Sistema de variables (`css/variables.css`)

Todo el CSS usa variables de `:root`; no hay colores, tamaños ni fuentes «sueltos» en los componentes:

- **Colores:** `--color-felt*` (verde fieltro), `--color-gold*` (oro), `--color-night*` (fondos), `--color-ivory`, `--color-ink*` (texto sobre claro) y estados `--color-success`, `--color-danger`, `--color-draw`.
- **Espaciado:** escala de 8 px → `--space-1` (8) … `--space-12` (96).
- **Radios y sombras:** `--radius-sm/md/lg/round`, `--shadow-low/mid/high`.
- **Fuentes:** `--font-display` (Playfair Display) y `--font-body` (Inter), ambas con fuente de respaldo.

### 3.2 Grid y Flexbox (sin posiciones absolutas de Figma)

| Zona | Técnica | Motivo |
|---|---|---|
| Cabecera y menú | **Flexbox** | Una sola dimensión: logo a la izquierda, enlaces a la derecha |
| Hero | **Grid** 2 columnas (`1.15fr .85fr`) | Texto + cartas decorativas |
| Estadísticas | **Grid** 4 columnas | Cuatro bloques iguales |
| Tarjetas del dashboard | **Grid** 3 columnas | Cuadrícula bidimensional |
| Marcador (`.scoreline`) | **Grid** `1fr auto 1fr` | «Tú · VS · Banca» centrado |
| Login / Registro | **Grid** 2 columnas | Presentación + formulario |
| Formulario de crear | **Grid** 2 columnas (campo ancho: `grid-column: 1 / -1`) | Campos alineados en parejas |
| Detalle | **Grid** `1.6fr 1fr` | Ficha + panel de acciones |
| Mesa de juego | **Grid** de 3 filas + **Flexbox** para las manos | Banca / mensaje / jugador |
| Filtros, botones, pie | **Flexbox** | Alineación y reparto en línea |

Las únicas posiciones absolutas son decorativas o de superposición (el «21» de fondo del hero, el símbolo central de las cartas, el desplegable del menú móvil y el texto solo para lectores de pantalla), nunca para colocar contenido.

### 3.3 Diseño responsive y puntos de ruptura

El diseño base es el de **escritorio** (`layout.css`) y se **adapta hacia abajo** con `max-width` en `responsive.css`:

| Breakpoint | Dispositivo | Cambios principales |
|---|---|---|
| Base (> 1099 px) | Escritorio | Tarjetas en 3 columnas, menú horizontal, hero en 2 columnas |
| `≤ 1099px` | Portátil pequeño / tablet horizontal | Tarjetas en 2 columnas, detalle en 1 columna |
| `≤ 767px` | Tablet vertical y móvil | Menú hamburguesa, tarjetas en 1 columna, estadísticas 2×2, login/registro apilados, formularios a 1 columna, mesa con cartas más pequeñas, modales con botones apilados |
| `≤ 479px` | Móvil pequeño | Ajustes de tamaños de texto, botones de la mesa en 2 por fila |

Comprobado sin desbordamiento horizontal en **1440, 1024, 768, 390 y 320 px** en todas las páginas.

### 3.4 HTML semántico y accesibilidad

- Estructura con `<header>`, `<nav>`, `<main>`, `<section>`, `<article>`, `<aside>` y `<footer>`; un único `<h1>` por página y jerarquía de títulos ordenada.
- `<label for>` en todos los campos, `aria-describedby` hacia el mensaje de error, `aria-invalid` y `role="alert"` en los errores.
- Menú hamburguesa con `aria-expanded` / `aria-controls`; enlace activo con `aria-current="page"`.
- Modales con `role="dialog"`, `aria-modal`, foco atrapado, cierre con Escape y devolución del foco.
- Resultados del buscador anunciados con una región `aria-live`; `prefers-reduced-motion` respetado.

## 4. Lógica JavaScript implementada

### 4.1 Datos simulados y renderizado dinámico del DOM

`js/mockData.js` contiene un array de objetos que simula la tabla `partidas` del Proyecto 1 (`id`, `name`, `playedAt`, `result`, `playerScore`, `dealerScore`, `hands`, `decks`, `notes`).

`js/dashboard.js` hace el renderizado:

1. Une las partidas reales del usuario (`storage.js`) con `mockMatches` y las ordena por fecha.
2. Por cada partida **clona la `<template id="match-card-template">`** de `index.html`, rellena los campos (`data-field`) y la añade a la cuadrícula.
3. `detalle.js` lee `?id=` de la URL, busca la partida y pinta la ficha; si no existe muestra un estado «no encontrada».

### 4.2 Validación de formularios en tiempo real (`js/validation.js`)

Los formularios llevan `novalidate`: **no se usan los tooltips del navegador**. Cada campo declara su regla en el HTML (`data-rule="email"`) y el módulo pinta el mensaje en un `<p class="field__message">` dentro del DOM.

- **Cuándo valida:** en `input` y `change` mientras se escribe, en `blur` al salir del campo y al enviar (marca todo y enfoca el primer error). Un campo vacío al que no se ha llegado a escribir no se marca solo por pasar por él.
- **Estados visuales:** error (rojo + icono `!`) y correcto (verde + icono `✓`).

| Regla | Campo | Comprobaciones |
|---|---|---|
| `name` | Nombre de usuario | 3–20 caracteres, letras/números/`_ . -` |
| `email` | Correo | Formato `algo@dominio.ext` |
| `loginPassword` / `newPassword` | Contraseña | ≥ 8 caracteres; en el alta, al menos una letra y un número |
| `confirm` | Repetir contraseña | Coincide con la contraseña (se revalida si ésta cambia) |
| `birthDate` | Fecha de nacimiento | Fecha válida, no futura, año ≥ 1900 y **mayor de 18** |
| `terms` | Casilla de términos | Obligatoria |
| `matchName` | Nombre de la partida | 3–40 caracteres |
| `matchDate` | Fecha de la partida | Válida, no futura, ≥ 2020 |
| `required` | Resultado (select) | Hay que elegir una opción |
| `score` / `hands` | Puntuaciones / manos | Enteros en rango (0–31 / 1–20) |
| `notes` | Notas | ≤ 200 caracteres, con contador en vivo |

### 4.3 Componentes interactivos

- **Menú hamburguesa** (`layout.js`): se abre/cierra con el botón, Escape o clic fuera; se cierra solo al ensanchar la ventana.
- **Buscador y filtros en tiempo real** (`dashboard.js`): filtra las tarjetas mientras se escribe, combinado con los filtros Todas / Victorias / Derrotas / Empates, con estado vacío y botón «Limpiar filtros».
- **Modales** (`dom.js › openModal`): reglas del juego, confirmar cierre de sesión, recuperar contraseña, abandonar partida, resultado de la ronda, partida guardada y confirmar eliminación.
- **Mesa de Blackjack** (`game.js` + `jugar.js`): reparto aleatorio con 6 barajas, pedir, plantarse, doblar, dividir, turno de la banca y atajos de teclado (P, S, N). Cada ronda terminada se guarda en el historial y aparece en el dashboard.

### 4.4 Sesión y persistencia (simulan el backend)

- Registro e inicio de sesión contra `localStorage`; las contraseñas se guardan con **hash SHA-256 + sal**, nunca en claro.
- **Modo invitado** en `sessionStorage`: sus datos se borran al salir.
- Las páginas privadas redirigen a `login.html` si no hay sesión; login y registro redirigen al inicio si ya la hay.
- CRUD de partidas en `storage.js` (`addMatch`, `findMatch`, `deleteMatch`), listo para sustituirse por llamadas al backend en los siguientes proyectos.

## 5. Pruebas realizadas

Se probó la web abriéndola directamente desde archivos (`file://`) con un navegador automatizado: flujo completo de registro → dashboard → buscador/filtros → detalle → crear → jugar → eliminar → cerrar sesión; validaciones de todos los formularios; menú hamburguesa; y ausencia de desbordamiento horizontal en 5 anchos de pantalla. Sin errores en la consola del navegador.

## 6. Despliegue

El proyecto es 100 % estático. Para publicarlo en **GitHub Pages**: subir el contenido de esta carpeta a la raíz de `proyecto-daw-frontend` y activar *Settings → Pages → Deploy from a branch → main / (root)*. Con Netlify o Vercel basta con arrastrar la carpeta (sin comando de build).
